import base64
import gzip
import io
import json
import logging
import os
import subprocess
import sys
import time
import signal
import argparse

class SimpleLogger:
    def __init__(self):
        # 获取当前 Python 文件的名称（不带扩展名）
        current_file_name = os.path.splitext(os.path.basename(__file__))[0]
        
        # 确保日志文件夹存在
        log_dir = os.path.join(os.getcwd(), 'logs')
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        # 设置日志文件路径，格式为 current_file_name.log
        log_file_path = os.path.join(log_dir, f"{current_file_name}.log")
        
        # 配置日志记录器
        logging.basicConfig(
            filename=log_file_path,  # 写入到指定文件
            filemode='a',  # 追加模式
            level=logging.INFO  # 记录 DEBUG 级别及以上日志
        )

    def log(self, message):
        # 写入日志
        logging.info(message)

class ComfyUIConfig:
    def __init__(self, json_data):
        try:
            config = json.loads(json_data)
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON data provided")
        
        self.current_dir = os.path.dirname(os.path.abspath(__file__))
        self.port = config.get('port', 6607) 
        self.comfyui_script_name = config.get('comfyui_script_name', 'main.py')
        self.working_directory = config.get('working_directory', self.current_dir)
        self.env_cmd = config.get('env_cmd', '')
        self.add_cmd = config.get('add_cmd', '')
        self.env_vars = config.get('env_vars',[])


class ProcessManager:
    def __init__(self, command, env_vars=None):
        self.command = command
        self.env_vars = env_vars or {}
        self.child_process = None
        self.parent_pid = os.getppid()
        self.command_working_directory = os.path.dirname(os.path.abspath(__file__))

    def set_environment_variables(self):
        for key, value in self.env_vars.items():
            if key not in os.environ:
                os.environ[key] = value

    def start_child_process(self):
        # Activate conda environment before starting the child process
        # conda_activate_command = f" &&"
        self.command = f"{self.command}"
        self.set_environment_variables()
        self.child_process = subprocess.Popen(
            self.command, shell=True, cwd=self.command_working_directory
        )

    def monitor_parent(self):
        def is_parent_alive():
            try:
                if os.name == 'nt':
                    # On Windows, using OpenProcess to check if the parent process exists
                    import ctypes
                    PROCESS_QUERY_INFORMATION = 0x0400
                    handle = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_INFORMATION, 0, self.parent_pid)
                    if handle == 0:
                        print(f"OpenProcess failed for parent process {self.parent_pid}")
                        return False
                    ctypes.windll.kernel32.CloseHandle(handle)
                    return True
                else:
                    # On POSIX, using kill with signal 0 to check existence without killing
                    os.kill(self.parent_pid, 0)
                return True
            except OSError:
                return False
            except Exception as e:
                print(f"Error checking parent process: {e}")
                return False
        try:
            while True:
                if (os.name == 'posix' and not os.path.exists(f'/proc/{self.parent_pid}')) or (os.name == 'nt' and not is_parent_alive()):
                    print("Parent process has exited. Terminating child process...")
                    self.terminate_child()
                    break
                time.sleep(1)
        except KeyboardInterrupt:
            print("Process interrupted by user. Terminating child process...")
            self.terminate_child()

    def terminate_child(self):
        if self.child_process:
            self.child_process.send_signal(signal.CTRL_BREAK_EVENT)
            self.child_process.wait()
        sys.exit(0)

    def run(self):
        self.start_child_process()
        self.monitor_parent()


sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')


# 过滤掉 --listen 和 --port 参数，避免重复
def filter_add_cmd(add_cmd):
    # Initialize an empty list to store the filtered arguments
    filtered_add_cmd = []
    
    # Flag to skip the next argument, which is used when encountering "--listen" or "--port"
    skip_next = False
    
    # If add_cmd is None or an empty string, return an empty string immediately
    if not add_cmd:
        return ""
    
    try:
        # Split the input string into individual arguments
        for arg in add_cmd.split():
            # If skip_next is True, we skip this argument and reset skip_next to False
            if skip_next:
                skip_next = False
                continue
            
            # If the argument is "--listen" or "--port", set skip_next to True to skip the next argument
            if arg in ["--listen", "--port"]:
                skip_next = True
                continue
            
            # Add the argument to the filtered list if it's not skipped
            filtered_add_cmd.append(arg)
    
    except Exception as e:
        # Catch any unexpected exceptions and print an error message
        print(f"Error processing add_cmd: {e}")
        return ""
    
    # Join the filtered arguments back into a single string and return it
    return " ".join(filtered_add_cmd)



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Start the child process and monitor parent process.")
    parser.add_argument("--parameter", type=str, help="base64 parameter for the child process.")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()

    if not args.parameter:
        print("parameter is required")
        sys.exit(1)


    logger = SimpleLogger()
    
    if args.debug:
        logger.log(f"start_comfyui.py args: {args.parameter}")

    # 1. 将 Base64 字符串解码为二进制数据
    gzip_data = base64.b64decode(args.parameter)
    
    # 2. 使用 gzip 解压数据
    json_str = ""
    with gzip.GzipFile(fileobj=io.BytesIO(gzip_data), mode='rb') as gz:
        # 读取解压后的数据并解析为 JSON
        json_str = gz.read().decode('utf-8')  # 解码为 UTF-8 字符串

    if args.debug:
        logger.log(f"start_comfyui.py config: {json_str}")

    comfyui_config = ComfyUIConfig(json_str)
    add_cmd = filter_add_cmd(comfyui_config.add_cmd).strip()

    if add_cmd:
        command = f"python {comfyui_config.comfyui_script_name} --port {comfyui_config.port} --listen 127.0.0.1 {add_cmd}"
    else:
        command = f"python {comfyui_config.comfyui_script_name} --port {comfyui_config.port} --listen 127.0.0.1"

    if comfyui_config.env_cmd:
        command = f"{comfyui_config.env_cmd} && {command}"

    # env_vars = {
    #     "HF_ENDPOINT": "https://hf-mirror.com"
    # }

    manager = ProcessManager(command, comfyui_config.env_vars)
    manager.command_working_directory = comfyui_config.working_directory
    manager.run()
